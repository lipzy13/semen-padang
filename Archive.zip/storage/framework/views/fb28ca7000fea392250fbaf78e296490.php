<div>
    <form class="row g-3" id="workOrderForm" wire:submit="save">
        <div class="form-check">
            <label for="validationDefault04" class="form-label">Area</label>
            <select class="form-select" aria-label="Large select example" wire:model="area">
                <option disabled selected value="">Area</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\Area::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $are): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($are->id); ?>><?php echo e($are->nama_area); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </select>


            <label for="validationDefault04" class="form-label"> Route</label>

            <select class="form-select" aria-label="Large select example" wire:model="route">
                <option disabled selected value="">Route</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\Route::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rou): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($rou->id); ?>><?php echo e($rou->nama_route); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </select>
            <br>
            <!-- Kotak isian PIC pertama -->
            <label for="pic" class="">PIC</label>
            <select id="pic" class="form-select" wire:model="pic.0">
                <option disabled selected value="">PIC</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $use): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($use->username); ?>" ><?php echo e($use->username); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </select>

            <?php $__currentLoopData = $pic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tangg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key>0): ?>
                    <div>
                        <select id="pic" class="form-select my-2" wire:model="pic.<?php echo e($key); ?>">
                            <option disabled selected value="">PIC</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($us->username); ?>"><?php echo e($us->username); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            <br>
            <button wire:click.prevent="removePic">
                Hapus </button>
            <button wire:click.prevent="addPic" class="">Tambah PIC</button>
        </div>

        <div class="form-check">
            <label for="validationDefault04" class="form-label">Tanggal</label>
            <input type="date" class="form-control" id="validationDefault04" required wire:model="tanggal">
        </div><br>

        <div class="form-check">
            <label for="alat" class="">Kode Alat</label>
            <select id="alat" class="form-select" wire:model="alat.0">
                <option disabled selected value="">Alat</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\Alat::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $use): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($use->id); ?>" ><?php echo e($use->kode_alat); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </select>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\Aksi::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <input type="checkbox" value="<?php echo e($aksi->id); ?>" id="flexCheckDefault<?php echo e($aksi->id); ?>" wire:model="aksi.0">
                    <label for="flexCheckDefault<?php echo e($aksi->id); ?>">
                        <?php echo e($aksi->nama); ?>

                    </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            <div class="form-check form-check-inline">
                <input  type="radio" name="inlineRadioOptions" id="inlineRadio01" value=1 wire:model="kondisi.0">
                <label for="inlineRadio01">ok</label>
            </div>
            <div class="form-check form-check-inline">
                <input type="radio" name="inlineRadioOptions" id="inlineRadio02" value=0 wire:model="kondisi.0">
                <label for="inlineRadio02">not ok</label>
            </div>
            <div class="mb-3">
                <label for="validationTextarea" class="form-label">Abnormalitas</label>
                <textarea class="form-control" id="validationTextarea" placeholder="Masukan teks" wire:model="abnormalitas.0" ></textarea>
            </div>

            <?php $__currentLoopData = $alat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tangg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key>0): ?>
                    <div>
                        <select id="alat" class="form-select my-2" wire:model="alat.<?php echo e($key); ?>">
                            <option disabled selected value="">Alat</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\Alat::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($us->id); ?>"><?php echo e($us->kode_alat); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\Aksi::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input  type="checkbox" value="<?php echo e($aksi->id); ?>" id="flexCheck<?php echo e($key); ?>/<?php echo e($aksi->id); ?>" wire:model="aksi.<?php echo e($key); ?>">
                            <label  for="flexCheck<?php echo e($key); ?>/<?php echo e($aksi->id); ?>">
                                <?php echo e($aksi->nama); ?>

                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                    <div class="form-check form-check-inline">
                        <input  type="radio" name="inlineRadioOptions<?php echo e($key); ?>" id="inlineRadio1<?php echo e($key); ?>1" value=1 wire:model="kondisi.<?php echo e($key); ?>">
                        <label for="inlineRadio<?php echo e($key); ?>1">ok</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input type="radio" name="inlineRadioOptions<?php echo e($key); ?>" id="inlineRadio<?php echo e($key); ?>2" value=0 wire:model="kondisi.<?php echo e($key); ?>">
                        <label for="inlineRadio<?php echo e($key); ?>2">not ok</label>
                    </div>
                    <div class="mb-3">
                        <label for="validationTextarea" class="form-label">Abnormalitas</label>
                        <textarea class="form-control" id="validationTextarea" placeholder="Masukan teks" required wire:model="abnormalitas.<?php echo e($key); ?>" ></textarea>
                    </div>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            <br>
            <div class="form-check">
                <button wire:click.prevent="removeAlat">
                    Hapus </button>
                <button wire:click.prevent="addAlat" class="">Tambah Alat</button>
            </div>
        </div>

        <div class="form-check">
            <!-- Tombol untuk menambahkan kotak isian PIC baru -->
            <button class="btn btn-primary" type="submit">Submit</button>
        </div>

        <div class="form-check">
            <a class="btn btn-secondary" href="/">Kembali</a>
        </div>
    </form>
</div>
<?php /**PATH /Users/aliefadha/codingg/web-dev/laravel/semen-padang/resources/views/livewire/basic-maintenance.blade.php ENDPATH**/ ?>