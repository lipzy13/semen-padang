<div>
    <form class="row g-3" id="workOrderForm" wire:submit="save">
        <?php echo csrf_field(); ?>
        <div class="form-check">
            <label for="pic" class="">PIC</label>
            <select id="pic" class="form-select" wire:model="pic.0">
                <option disabled selected value="">PIC</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $use): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($use->username); ?>" ><?php echo e($use->username); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </select>

            <?php $__currentLoopData = $pic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tangg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key>0): ?>
                    <div>
                        <select id="pic" class="form-select my-2" wire:model="pic.<?php echo e($key); ?>">
                            <option disabled selected value="">PIC</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($us->username); ?>"><?php echo e($us->username); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            <br>
            <button wire:click.prevent="removePic">
                Hapus </button>
            <button wire:click.prevent="addPic" class="">Tambah PIC</button>
        </div>
        <div class="col-md-3">
            <label for="tanggal_mulai" class="form-label">Tanggal Mulai</label>
            <input type="date" class="form-control" name="tanggal_mulai" id="tanggal_mulai" wire:model="tanggal_mulai" required>
        </div>
        <div class="form-check col-md-4">
            <label for="validationDefault02" class="form-label">Kode Alat</label>
            <select class="form-select"  name="alat" id="alat" wire:model="alat">
                <option disabled selected value="">Alat</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\Alat::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $al): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($al->id); ?>"><?php echo e($al->kode_alat); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </select>
        </div>
        <div class="mb-3">
            <label for="abnormalitas" class="form-label">Abnormalitas</label>
            <textarea class="form-control" id="abnomralitas" name="abnormalitas" id="abnormalitas" required placeholder="Masukkan teks" wire:model="abnormalitas"></textarea>
        </div>
        <div class="mb-3">
            <label for="action" class="form-label">Action</label>
            <textarea class="form-control" id="action" name="action" placeholder="Masukkan teks" required wire:model="action"></textarea>
        </div>
        <div class="form-check form-check-inline">
            <input  type="radio" name="kondisi" id="inlineRadio1" value=1 id="kondisi" wire:model="kondisi">
            <label for="inlineRadio1">ok</label>
        </div>
        <div class="form-check form-check-inline">
            <input type="radio" name="kondisi" id="inlineRadio2" value=0 id="kondisi" wire:model="kondisi">
            <label for="inlineRadio2">not ok</label>
        </div>
        <div class="col">
            <label for="tanggal_selesai" class="form-label">Tanggal Selesai</label>
            <input type="date" class="form-control" name="tanggal_selesai" id="tanggal_selesai" required wire:model="tanggal_selesai"  required>
        </div>
        <div class="col-12">
            <!-- Tombol untuk menambahkan kotak isian PIC baru -->
            <button class="btn btn-primary" type="submit" >Submit</button>
        </div>
    </form>
    <div class="mt-3">
        <a class="btn btn-secondary" href="/">Kembali</a>
    </div>
</div>

<?php /**PATH /Users/aliefadha/codingg/web-dev/laravel/semen-padang/resources/views/livewire/work-order.blade.php ENDPATH**/ ?>