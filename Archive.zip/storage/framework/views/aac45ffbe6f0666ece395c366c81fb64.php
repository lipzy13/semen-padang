<?php $__env->startSection('container'); ?>
    <div class="container-fluid px-4">
        <h1>Workorder</h1><br/>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('work-order', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2701935719-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aliefadha/codingg/web-dev/laravel/semen-padang/resources/views/workOrder.blade.php ENDPATH**/ ?>