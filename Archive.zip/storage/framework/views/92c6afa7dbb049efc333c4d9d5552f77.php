<?php $__env->startSection('container'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">History Pemeriksaan</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="/">Dashboard</a></li>
            <li class="breadcrumb-item active">History Pemeriksaan</li>
        </ol>

    </div>
    <div class="card mb-4">
        <div class="card-header">
            tabel workorder
        </div>
        <div class="container mt-4">
            <table class="table">
                <thead>
                <tr>
                    <th>TANGGAL MULAI</th>
                    <th>TANGGAL SELESAI</th>
                    <th>PIC</th>
                    <th>ALAT</th>
                    <th>ABNORMALITAS</th>
                    <th>ACTION</th>
                    <th>KONDISI</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = \App\Models\workOrder::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worko): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($worko->tanggal_mulai); ?></td>
                        <td><?php echo e($worko->tanggal_selesai); ?></td>
                        <td>
                            <ul>
                                <?php $__currentLoopData = \App\Models\pic_workorder::where('work_order_id', $worko->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($pic->nama); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </td>
                        <td><?php echo e($worko->alat->kode_alat); ?></td>
                        <td><?php echo e($worko->abnormalitas); ?></td>
                        <td><?php echo e($worko->action); ?></td>
                        <td><?php echo e($worko->kondisi ? 'ok' : 'not ok'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <a href="/work-order/delete" class="btn-danger btn my-2">Hapus</a>
            <a href="/work-order/download" class="btn-success btn my-2">Download</a>
        </div>

    </div>

    <div class="card mb-4">
        <div class="card-header">
            tabel basic maintance
        </div>
        <div class="container mt-4">
            <table class="table">
                <thead>
                <tr>
                    <th>AREA</th>
                    <th>ROUTE</th>
                    <th>PIC</th>
                    <th>TANGGAL</th>
                    <th>KODE ALAT</th>
                    <?php $__currentLoopData = \App\Models\Aksi::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semua_aksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($semua_aksi->nama); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th>kondisi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = \App\Models\basicMaintenance::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->area->nama_area); ?></td>
                        <td><?php echo e($data->route->nama_route); ?></td>
                        <td>
                            <ul>
                                <?php $__currentLoopData = \App\Models\Pic::where('basic_maintenances_id', $data->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php echo e($pic->nama); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </td>
                        <td><?php echo e($data->tanggal->format('d/m/Y')); ?></td>
                        <td>
                            <ul>
                                    <li><?php echo e(\App\Models\Alat::where('id', $data->alat)->value('kode_alat')); ?></li>
                            </ul>
                        </td>
                        <?php $aksi_list = \App\Models\AksiList::where('basic_maintenance_id', $data->id)->pluck('aksi_id')->all() ?>
                        <?php $__currentLoopData = \App\Models\Aksi::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(in_array($aksi->id, $aksi_list)): ?>
                                <td align="center" style="font-family: wingdings; font-size:150%;font-weight:bold; font-color:green">&#10004;</td>
                            <?php else: ?>
                                <td align="center" style="font-family: wingdings; font-size:150%;font-weight:bold; font-color:green"></td>
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td>
                                    <?php echo e($data->kondisi ? 'ok' : 'not ok'); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- Tambahkan baris sesuai kebutuhan -->
                </tbody>
            </table>
            <a href="/basic-maintenance/delete" class="btn-danger btn my-2">Hapus</a>
            <a href="/basic-maintenance/download" class="btn-success btn my-2">Download</a>
        </div>

    </div>
    <footer class="py-4 bg-light mt-auto">

    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aliefadha/codingg/web-dev/laravel/semen-padang/resources/views/history.blade.php ENDPATH**/ ?>