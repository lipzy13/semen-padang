@extends('layouts.main')

@section('container')
    <div class="container-fluid px-4">
        <h1>Basic Maintance</h1><br>
        <livewire:basic-maintenance />
    </div>
@endsection
