@extends('layouts.main')

@section('container')
    <div class="container-fluid px-4">
        <h1>Workorder</h1><br/>
        <livewire:work-order/>
    </div>
@endsection
